GJReels Premium Website
========================

1. Upload index.html to your hosting provider's public website folder (often named public_html, www, or htdocs).
2. Connect your domain to that hosting account.
3. Replace the Gallery placeholder with your video embeds or hosted video links.
4. Connect a real payment gateway before accepting payments.
5. Add a secure server-backed login/admin system before using admin features.

This package is a static front-end website. It does not include hosting, a domain,
video storage, payment processing, OTP authentication, or a backend admin system.
